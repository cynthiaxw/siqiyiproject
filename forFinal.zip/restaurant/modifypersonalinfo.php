<?php include('server.php') ?>

<!DOCTYPE html>
<html>
<head>
	<title>Personal Infomation</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

	<div class="header">
		<h2>Personal Infomation</h2>
	</div>

	<form method="post" action="modifypersonalinfo.php">

		<div class="input-group">

      <label>Name</label>
			<input type="name" name="name" value="<?php echo $name; ?>">
			<label>Email</label>
			<input type="email" name="email" value="<?php echo $email; ?>">
			<label>Phone</label>
			<input type="phone" name="phone" value="<?php echo $phone; ?>">
			<label>Password</label>
			<input type="password" name="password" value="<?php echo $password; ?>">


      <br/><button type="submit" class="button" name="btn_modify_confirm">Confirm</button>
			<br/><button type="submit" class="button" name="btn_modify_cancel">Cancel</button>

		</div>
	</form>
</body>
</html>
