<?php
	session_start();
	// variable declaration
	$username = "";
	$email    = "";
	$name 		= "";
	$phone		= "";
	$errors = array();

	// connect to database
	$db = mysqli_connect('localhost', 'root', '', 'restaurant');

	// Choose login user type
	if (isset($_POST['login_cust'])){
		$_SESSION['customer'] = 1;
		unset($_SESSION['manager']);
		unset($_SESSION['staff']);
		header('location: login.php');
	}
	if(isset($_POST['login_mngr'])){
		$_SESSION['manager'] = 1;
		unset($_SESSION['customer']);
		unset($_SESSION['staff']);
		header('location: login.php');
	}
	if(isset($_POST['login_staf'])){
		$_SESSION['staff'] = 1;
		unset($_SESSION['customer']);
		unset($_SESSION['manager']);
		header('location: login.php');
	}


	// Modify personal information
	// Get information from the database
	if(isset($_SESSION['modify_info']) && (isset($_SESSION['customer_logged']) || isset($_SESSION['manager_logged'])||isset($_SESSION['staff_logged']))){
		$username = $_SESSION['username'];
		if(isset($_SESSION['customer_logged'])){
		  $query = "SELECT * FROM customer WHERE cuser_name = '$username'";
		}
		else if(isset($_SESSION['manager_logged'])||isset($_SESSION['staff_logged'])){
		  $query = "SELECT * FROM restaurant_staff WHERE user_name = '$username'";
		}
		$result = mysqli_query($db, $query);
		$tuple = mysqli_fetch_assoc($result);
		$name = $tuple['name'];
		$email = $tuple['email'];
		$phone	= $tuple['phone_num'];
		$password = $tuple['password'];
		if(isset($_POST['btn_modify_confirm'])){  //modify user information
			// receive all input values from the form
			$email = mysqli_real_escape_string($db, $_POST['email']);
			$name = mysqli_real_escape_string($db, $_POST['name']);
			$phone = mysqli_real_escape_string($db, $_POST['phone']);
			$password = mysqli_real_escape_string($db, $_POST['password']);

			// form validation: ensure that the form is correctly filled
			if (empty($name)) { array_push($errors, "Name is required"); }
			if (empty($email)) { array_push($errors, "Email is required"); }
			if (empty($phone)) { array_push($phone, "Phone is required"); }
			if (empty($password)) { array_push($errors, "Password is required"); }

			if(count($errors) == 0){
			  if(isset($_SESSION['customer_logged'])){
			    $query = "UPDATE customer
			          SET email = '$email', name = '$name', phone_num = '$phone', password = '$password'
			          WHERE cuser_name = '$username'";

			  }
			  else if(isset($_SESSION['manager_logged'])||isset($_SESSION['staff_logged'])){
			    $query = "UPDATE restaurant_staff
			          SET email = '$email', name = '$name', phone_num = '$phone', password = '$password'
			          WHERE user_name = '$username'";
			  }
			  mysqli_query($db, $query);
				unset($_SESSION['modify_info']);
				header('location: homepage.php');
			}
		}

		if(isset($_POST['btn_modify_cancel'])){
			unset($_SESSION['modify_info']);
			header('location: homepage.php');
		}
	}

	// LOGIN USER
	if (isset($_POST['login_done'])) {
		$username = mysqli_real_escape_string($db, $_POST['username']);
		$password = mysqli_real_escape_string($db, $_POST['password']);

		if (empty($username)) {
			array_push($errors, "Username is required");
		}
		if (empty($password)) {
			array_push($errors, "Password is required");
		}

		if (count($errors) == 0) {
			unset($_SESSION['order_id']);
			if(isset($_SESSION['customer'])){
				$query = "SELECT * FROM customer WHERE cuser_name='$username' AND password='$password'";
				$_SESSION['customer_logged'] = 1;
			}
			else if(isset($_SESSION['manager'])){
				$query = "SELECT * FROM manager NATURAL JOIN restaurant_staff WHERE user_name='$username' AND password='$password'";
				$_SESSION['manager_logged'] = 1;
			}
			else if(isset($_SESSION['staff'])){
				$query = "SELECT * FROM general_staff NATURAL JOIN restaurant_staff WHERE user_name='$username' AND password='$password'";
				$_SESSION['staff_logged'] = 1;
			}
			$results = mysqli_query($db, $query);

			if (mysqli_num_rows($results) == 1) {
				$_SESSION['username'] = $username;
				if(isset($_SESSION['customer'])){
				$order_query = "SELECT order_id FROM customer_order WHERE Order_state = 'not_placed' AND cust_name = '$username'";
				$order_result = mysqli_query($db, $order_query);
				$order_tuple =mysqli_fetch_assoc($order_result);
				}
				if (mysqli_num_rows($order_result) >= 1) {
 					$_SESSION['order_id'] = $order_tuple['order_id'];
				} else{
					$max_order_id_query = "SELECT MAX(order_id) as max_order_id FROM  customer_order";
					$max_order_id_results = mysqli_query($db, $max_order_id_query);
					$max_order_id_tuple = mysqli_fetch_assoc($max_order_id_results);
					$new_order_id =  $max_order_id_tuple['max_order_id']+1;
					$_SESSION['order_id'] = $new_order_id;
					$insert_order_query = "INSERT INTO customer_order(order_id, Order_state, Cancellability, cust_name)
											VALUES ('$new_order_id', 'not_placed', 'yes', '$username')";
					$insert_order_resutl = mysqli_query($db, $insert_order_query);
				}
 					header('location: homepage.php');
			}else {
				array_push($errors, "Wrong username or password.");
			}
		}
		unset($_SESSION['login_done']);
	}



?>

<?php





	// REGISTER USER
	if (isset($_POST['reg_user'])) {
		// receive all input values from the form
		$username = mysqli_real_escape_string($db, $_POST['username']);
		$email = mysqli_real_escape_string($db, $_POST['email']);
		$name = mysqli_real_escape_string($db, $_POST['name']);
		$phone = mysqli_real_escape_string($db, $_POST['phone']);
		$password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
		$password_2 = mysqli_real_escape_string($db, $_POST['password_2']);

		// form validation: ensure that the form is correctly filled
		if (empty($username)) { array_push($errors, "Username is required"); }
		if (empty($name)) { array_push($errors, "Name is required"); }
		if (empty($email)) { array_push($errors, "Email is required"); }
		if (empty($phone)) { array_push($phone, "Phone is required"); }
		if (empty($password_1)) { array_push($errors, "Password is required"); }

		if ($password_1 != $password_2) {
			array_push($errors, "The two passwords do not match");
		}

		// register user if there are no errors in the form
		if (count($errors) == 0) {
			$query = "INSERT INTO customer (cuser_name, email, name, phone_num, password)
					  VALUES('$username', '$email', '$name', '$phone', '$password_1')";
			mysqli_query($db, $query);

			$_SESSION['username'] = $username;

			$max_order_id_query = "SELECT MAX(order_id) as max_order_id FROM  customer_order";
			$max_order_id_results = mysqli_query($db, $max_order_id_query);
			$max_order_id_tuple = mysqli_fetch_assoc($max_order_id_results);
			$new_order_id =  $max_order_id_tuple['max_order_id']+1;
			$_SESSION['order_id'] = $new_order_id;
			$insert_order_query = "INSERT INTO customer_order(order_id, Order_state, Cancellability, cust_name)
										VALUES ('$new_order_id', 'not_placed', 'yes', '$username')";
			$insert_order_resutl = mysqli_query($db, $insert_order_query);
			$_SESSION['customer_logged'] = 1;

			header('location: homepage.php');
		}

	}
 ?>

<?php  if (count($errors) > 0) : ?>
	<div class="error">
		<?php foreach ($errors as $error) : ?>
			<p><?php echo $error ?></p>
		<?php endforeach ?>
	</div>
<?php  endif ?>
