﻿<html>
 <head>
  <title>Reserve a table</title>	

 </head>
 <body>
 	 <a href =\try\homepage.php>Back to homepage</a>
 	<?php
 	  session_start();
 	  $r_db = mysqli_connect("localhost","root", "", "resturant");
 	  $order_id = $_SESSION['order_id'];
 	  $se_table_query = "SELECT * FROM table_information WHERE availability = 'YES'" ;
 	  $se_table_result = mysqli_query($r_db, $se_table_query);
 	  $num_result = mysqli_num_rows($se_table_result);
 		if ($num_result > 0) {
 			while ($table_tuple = mysqli_fetch_assoc($se_table_result)){
				
 				echo "<div>
 					<h2>".$table_tuple['table_id']."</h2>
 					<p>".$table_tuple['capacity']."</p>
 					 <a href =\\tableTimeSlot.php?table_id=".$table_tuple['table_id'].">Change to this table</a>
 				</div>";

 		}
 	}
 	?>



 </div>
 </body>
</html>