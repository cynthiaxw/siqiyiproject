﻿<html>
 <head>
  <title>Order information</title>	

 </head>
 <body>
 	 <a href =\try\homepage.php>Back to homepage</a>
 	<?php
 	  session_start();
 	  $r_db = mysqli_connect("localhost","root", "", "resturant");
 	  $order_id = $_SESSION['order_id'];



 	  if (isset($_GET['id'])){
 	  $food_id = $_GET['id'];
 	  $order_id = $_SESSION['order_id'];
 	  $action = $_GET['action'];
 	  $se_include_query = "SELECT num_of_food FROM include WHERE order_id = '$order_id' AND food_id = '$food_id'" ;
 	  $se_include_result = mysqli_query($r_db, $se_include_query);
 	  $num_se_include_result = mysqli_num_rows($se_include_result);
 	  if($action == 'increase'){
 		  	if($num_se_include_result == 1){
 	  			$num_of_food_tuple = mysqli_fetch_assoc($se_include_result);
 	  			$num_of_food = $num_of_food_tuple['num_of_food'];
 	  		 	$num_of_food = $num_of_food + 1;
 	  		 	$increase_num_query = "UPDATE include SET num_of_food = '$num_of_food' WHERE order_id = '$order_id' AND food_id = '$food_id'" ;
 	 		 	$increase_num_result = mysqli_query($r_db, $increase_num_query);

 	  		} else {
 	  			$in_include_query = "INSERT INTO include VALUES ('1', '$food_id', '$order_id')"; 
 	  			$in_include_result = mysqli_query($r_db, $in_include_query);
 			}
 			echo "<div>You have successfully increased the quantity of the food.</div>";
 	   } else if ($action == 'reduce'){
 	   	 	$num_of_food_tuple = mysqli_fetch_assoc($se_include_result);
 	  		$num_of_food = $num_of_food_tuple['num_of_food'];
 	   	 	if($num_of_food > 1){
 	  		 	$num_of_food = $num_of_food - 1;
 	  		 	$increase_num_query = "UPDATE include SET num_of_food = '$num_of_food' WHERE order_id = '$order_id' AND food_id = '$food_id'" ;
 	 		 	$increase_num_result = mysqli_query($r_db, $increase_num_query);
 	  		} else {
 	  			$de_include_query = "DELETE FROM include WHERE order_id = '$order_id' AND food_id = '$food_id'"; 
 	  			$de_include_result = mysqli_query($r_db, $de_include_query);
 			}
 			echo "<div>You have successfully reduced the quantity of the food.</div>";
 	   } else {
 	  			$de_include_query = "DELETE FROM include WHERE order_id = '$order_id' AND food_id = '$food_id'"; 
 	  			$de_include_result = mysqli_query($r_db, $de_include_query);
 	  		echo "<div>You have successfully deleted the quantity of the food.</div>";
 	   }
 	  }


 	  $check_table_order_query = "SELECT * FROM  table_order O INNER JOIN table_time_slot T WHERE O.table_id=T.table_id AND O.table_start_time = T.table_start_time AND O.order_id = '$order_id'";
 	  $check_table_order_result = mysqli_query($r_db, $check_table_order_query);
 	  $num_table_order_result = mysqli_num_rows($check_table_order_result);
 	  if ($num_table_order_result == 1) {
 	  	while ($table_tuple = mysqli_fetch_assoc($check_table_order_result)){
 	  	 echo "<div><h2>You have made a reservation: </h2></div>";
 	  	 echo "<div><p>Table  ".$table_tuple['table_id']."</p>
 	  	             <p>Table  ".$table_tuple['table_start_time']."</p>
 	  	             <a href =\changeTable.php?>Change reservation</a>
 	  	             </div>";
 	  	 $_SESSION['changeTable'] = 1;
 	  	}
	}
 	?>

 	<div>
 		<p><h2> Your have ordered the food:</h2></p>
 		 <?php
 	  	$r_db = mysqli_connect("localhost","root", "", "resturant");
 	  	$order_id = $_SESSION['order_id'];
 		$query = "SELECT * FROM include NATURAL JOIN food WHERE order_id = $order_id";
 		$result = mysqli_query($r_db, $query);
 		$numResult = mysqli_num_rows($result);
 		if ($numResult > 0) {
 			while ($tuple = mysqli_fetch_assoc($result))	
 				echo "<div>
 					<h2>".$tuple['type']."</h3>
 					<p>".$tuple['food_id']."</p>
 					<p>".$tuple['name']."</p>
 					<p>".$tuple['availability']."</p>
 					<p>".$tuple['price']."</p>
 					<p> quantity:".$tuple['Num_of_food']."</p>
 				    <p><img src=\"".$tuple['picture']."\"></img></p>
 				     <a href =\order.php?id=".$tuple['food_id']."&action=reduce>Reduce</a>
 					 <a href =\order.php?id=".$tuple['food_id']."&action=increase>Increase</a>
 					 <a href =\order.php?id=".$tuple['food_id']."&action=delete>Delete</a>
 				</div>";
 		}

 		?>
 	</div>

 </body>
</html>