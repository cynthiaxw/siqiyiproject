﻿<html>
 <head>
  <title>Search</title>	

 </head>
 <body>
 	<?php
 	  session_start();
 	  $r_db = mysqli_connect("localhost","root", "", "resturant");
 	  $table_id = $_GET['table_id'];
 	  $start_time = $_GET['start_time'];
 	  $order_id = $_SESSION['order_id'];
 	  if (isset($_SESSION['changeTable'])){
 		  //$up_table_query = "UPDATE table_order SET table_id = '$table_id' AND table_start_time = '$start_time' WHERE order_id = '$order_id'";
 		 // $up_table_query = mysqli_query($r_db, $up_table_query);
 	  	  $de_table_query = "DELETE FROM table_order WHERE order_id = $order_id" ;
 		  $de_table_result = mysqli_query($r_db, $de_table_query);
 	  	  $in_table_query = "INSERT INTO table_order VALUES ('0', '$order_id', '$table_id', '$start_time')" ;
 		  $in_table_result = mysqli_query($r_db, $in_table_query);
 	  } else {
 		  $in_table_query = "INSERT INTO table_order VALUES ('0', '$order_id', '$table_id', '$start_time')" ;
 		  $in_table_result = mysqli_query($r_db, $in_table_query);
 	  }
 	  header('location: try/homepage.php');
 	?>



 </div>
 </body>
</html>