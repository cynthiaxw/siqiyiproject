﻿<html>
 <head>
  <title>Explore</title>
 </head>
 <body>
 <a href =homepage.php>Back to homepage</a>
 <h1> Explore result </h1>
 <div class = "search-result-container">
 	<?php
 	 session_start();
 	 $r_db = mysqli_connect("localhost","root", "", "restaurant");
 	 $username = $_SESSION['username'];
 		$query = "SELECT * FROM customer_order WHERE Order_state = 'processing' AND cust_name = '$username'";
 		$result = mysqli_query($r_db, $query);
 		$numResult = mysqli_num_rows($result);
 		if ($numResult > 0) {
 			while ($tuple = mysqli_fetch_assoc($result))
 				echo "<div>
 					<h2>".$tuple['order_id']."</h2>
 					 <a href =\\restaurant\\order.php?order_id=".$tuple['order_id'].">Modify</a>
 				</div>";
 		}

 	?>
 	 	<div><a href ="\restaurant\addTable.php?">Reserve a table(You can reserve a table without ordering food)</a></div>
 	 	<div><a href ="\restaurant\order.php?">Modify or place the order</a></div>
 </div>
 </body>
</html>
