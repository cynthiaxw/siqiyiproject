
<?php
	session_start();
?>

<?php if(!isset($_SESSION['add_new_food'])) : ?>

  <?php if(!isset($_SESSION['modify_f'])) :?>

    <?php if(!isset($_GET['add'])) : ?>

      <?php if(!isset($_GET['fid'])) : ?>

        <html>
         <head>
          <title>Modify Food</title>

         </head>
         <body>

         <h1> Modify Food </h1>

         <br/><a href="homepage.php">Back to home page.</a>
         <br/><a href="modifyfooditem.php?add">Add a new food.</a>

         <div class = "search-result-container">
         	<?php
         	  $r_db = mysqli_connect("localhost","root", "", "restaurant");
         		$query = "SELECT * FROM food";
         		$result = mysqli_query($r_db, $query);
         		$numResult = mysqli_num_rows($result);
         		if ($numResult > 0) {
         			while ($tuple = mysqli_fetch_assoc($result))
         				echo "<div>
         					<h2>Type: ".$tuple['type']."</h3>
         					<p>Food id： ".$tuple['food_id']."</p>
         					<p>Name: ".$tuple['name']."</p>
         					<p>Availability: ".$tuple['availability']."</p>
         					<p>Price: ".$tuple['price']."</p>
									<p>Food allergy: ".$tuple['food_allergy']."</p>
									<p>Food ingredient: ".$tuple['food_ingredient']."</p>
	    						<p><img src=\"".$tuple['picture']."\"></img></p>
         					 <a href =modifyfooditem.php?fid=".$tuple['food_id'].">Modify</a>
                   <a href =modifyfooditem.php?delete_id=".$tuple['food_id'].">Delete</a>
         				</div>";

         		}
         	?>
         </div>
         </body>
        </html>

      <?php endif?>

      <?php if(isset($_GET['fid'])) : ?>
        <?php

          $tmpFoodId = $_GET['fid'];
          $_SESSION['fId'] = $tmpFoodId;
          // Fetch food information from database
          $r_db = mysqli_connect("localhost","root", "", "restaurant");
          $query = "SELECT * FROM food WHERE food_id = '$tmpFoodId'";
          $result = mysqli_query($r_db, $query);
          $tuple = mysqli_fetch_assoc($result);

          $_SESSION['fType'] = $tuple['type'];
          $_SESSION['fName'] = $tuple['name'];
          $_SESSION['fPrice'] = $tuple['price'];
          $_SESSION['fAvailability'] = $tuple['availability'];
          $_SESSION['fPicture'] = $tuple['picture'];
					$_SESSION['fAllergy'] = $tuple['food_allergy'];
					$_SESSION['fIngredient'] = $tuple['food_ingredient'];

          $_SESSION['modify_f'] = 'yes';

        ?>
      <?php endif ?>

      <?php if(isset($_GET['delete_id'])) : ?>
        <?php
          $tmpFoodId = $_GET['delete_id'];
          $r_db = mysqli_connect("localhost","root", "", "restaurant");
          $query = "DELETE FROM food WHERE food_id = '$tmpFoodId'";
          $result = mysqli_query($r_db, $query);
          header('location: modifyfooditem.php');
        ?>
      <?php endif ?>

    <?php endif ?>

    <?php if(isset($_GET['add'])) : ?>
      <?php
        $_SESSION['add_new_food'] = 'yes';
      ?>
    <?php endif ?>

  <?php endif ?>

  <?php if(isset($_SESSION['modify_f'])) : ?>


    <!DOCTYPE html>
    <html>
    <head>
    	<title>Modify Food Item</title>
    	<link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>

    	<div class="header">
    		<h2>Modify Food Item</h2>
    	</div>

    	<form method="post" action="modifyfooditem.php">

    		<div class="input-group">
          <label>Food Id</label>
          <input type="fId" name="fId" value="<?php echo $_SESSION['fId']; ?>">
          <label>Type</label>
          <input type="fType" name="fType" value="<?php echo $_SESSION['fType']; ?>">
          <label>Name</label>
          <input type="fName" name="fName" value="<?php echo $_SESSION['fName']; ?>">
          <label>Price</label>
          <input type="fPrice" name="fPrice" value="<?php echo $_SESSION['fPrice']; ?>">
          <label>Availability</label>
          <input type="fAvailability" name="fAvailability" value="<?php echo $_SESSION['fAvailability']; ?>">
          <label>Picture</label>
          <input type="fPicture" name="fPicture" value="<?php echo $_SESSION['fPicture']; ?>">
					<label>Allergy</label>
					<input type="fAllergy" name="fAllergy" value="<?php echo $_SESSION['fAllergy']; ?>">
					<label>Ingredient</label>
					<input type="fIngredient" name="fIngredient" value="<?php echo $_SESSION['fIngredient']; ?>">


          <br/><button type="submit" class="button" name="btn_modifyf_confirm">Confirm</button>
    			<br/><button type="submit" class="button" name="btn_modifyf_cancel">Cancel</button>

    		</div>
    	</form>
    </body>
    </html>

    <?php
      if(isset($_POST['btn_modifyf_cancel'])){
        unset($_SESSION['modify_f']);
        header('location: modifyfooditem.php');
      }

      if(isset($_POST['btn_modifyf_confirm'])){
        $lastFoodId = $_SESSION['fId'];
        $r_db = mysqli_connect("localhost","root", "", "restaurant");

        $tmpFoodId = mysqli_real_escape_string($r_db, $_POST['fId']);
        $tmpFoodType = mysqli_real_escape_string($r_db, $_POST['fType']);
        $tmpFoodName = mysqli_real_escape_string($r_db, $_POST['fName']);
        $tmpFoodPrice = mysqli_real_escape_string($r_db, $_POST['fPrice']);
        $tmpFoodAvalability = mysqli_real_escape_string($r_db, $_POST['fAvailability']);
        $tmpFoodPicture = mysqli_real_escape_string($r_db, $_POST['fPicture']);
				$tmpFoodAllergy = mysqli_real_escape_string($r_db, $_POST['fAllergy']);
				$tmpFoodIngredient = mysqli_real_escape_string($r_db, $_POST['fIngredient']);


        $query = "UPDATE food
                  SET food_id = '$tmpFoodId', type = '$tmpFoodType', name = '$tmpFoodName', price = '$tmpFoodPrice', availability = '$tmpFoodAvalability', picture = '$tmpFoodPicture'
											,food_allergy = '$tmpFoodAllergy', food_ingredient = '$tmpFoodIngredient'
                  WHERE food_id = '$lastFoodId'";
        $result = mysqli_query($r_db, $query);

        unset($_SESSION['modify_f']);
        header('location: modifyfooditem.php');

      }
    ?>

  <?php endif ?>

<?php endif ?>

<?php if(isset($_SESSION['add_new_food'])) : ?>
  <?php
    $_SESSION['fId'] = "";
    $_SESSION['fType'] = "";
    $_SESSION['fName'] = "";
    $_SESSION['fPrice'] = "";
    $_SESSION['fAvailability'] = "";
    $_SESSION['fPicture'] = "";
		$_SESSION['fIngredient'] = "";
		$_SESSION['fAllergy'] = "";
  ?>

    <!DOCTYPE html>
    <html>
    <head>
    	<title>Add New Food Item</title>
    	<link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>

    	<div class="header">
    		<h2>Add New Food Item</h2>
    	</div>

    	<form method="post" action="modifyfooditem.php?add">

    		<div class="input-group">
          <label>Food Id</label>
          <input type="fId" name="fId" value="<?php echo $_SESSION['fId']; ?>">
          <label>Type</label>
          <input type="fType" name="fType" value="<?php echo $_SESSION['fType']; ?>">
          <label>Name</label>
          <input type="fName" name="fName" value="<?php echo $_SESSION['fName']; ?>">
          <label>Price</label>
          <input type="fPrice" name="fPrice" value="<?php echo $_SESSION['fPrice']; ?>">
          <label>Availability</label>
          <input type="fAvailability" name="fAvailability" value="<?php echo $_SESSION['fAvailability']; ?>">
          <label>Picture</label>
          <input type="fPicture" name="fPicture" value="<?php echo $_SESSION['fPicture']; ?>">
					<label>Allergy</label>
					<input type="fAllergy" name="fAllergy" value="<?php echo $_SESSION['fAllergy']; ?>">
					<label>Ingredient</label>
					<input type="fIngredient" name="fIngredient" value="<?php echo $_SESSION['fIngredient']; ?>">


          <br/><button type="submit" class="button" name="btn_addf_confirm">Confirm</button>
    			<br/><button type="submit" class="button" name="btn_addf_cancel">Cancel</button>
    		</div>
    	</form>
    </body>
    </html>


    <?php
      if(isset($_POST['btn_addf_cancel'])){
        unset($_SESSION['add_new_food']);
        header('location: modifyfooditem.php');
      }


      if(isset($_POST['btn_addf_confirm'])){
        $r_db = mysqli_connect("localhost","root", "", "restaurant");

        $tmpFoodId = mysqli_real_escape_string($r_db, $_POST['fId']);
        $tmpFoodType = mysqli_real_escape_string($r_db, $_POST['fType']);
        $tmpFoodName = mysqli_real_escape_string($r_db, $_POST['fName']);
        $tmpFoodPrice = mysqli_real_escape_string($r_db, $_POST['fPrice']);
        $tmpFoodAvalability = mysqli_real_escape_string($r_db, $_POST['fAvailability']);
        $tmpFoodPicture = mysqli_real_escape_string($r_db, $_POST['fPicture']);
				$tmpFoodAllergy = mysqli_real_escape_string($r_db, $_POST['fAllergy']);
				$tmpFoodIngredient = mysqli_real_escape_string($r_db, $_POST['fIngredient']);

        $query = "INSERT INTO food(type, food_id, picture, name, availability, price, food_ingredient, food_allergy)
                  VALUES ('$tmpFoodType', '$tmpFoodId', '$tmpFoodPicture', '$tmpFoodName', '$tmpFoodAvalability', '$tmpFoodPrice',
													'$tmpFoodIngredient', '$tmpFoodAllergy')";

        $result = mysqli_query($r_db, $query);

        unset($_SESSION['add_new_food']);
        header('location: modifyfooditem.php');

      }
    ?>


<?php endif ?>
