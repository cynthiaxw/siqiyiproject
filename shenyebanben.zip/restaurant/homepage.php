<?php include('server.php') ?>
<?php
//Home page
if(isset($_POST['btn_login'])){
	header('location: logintype.php');
}
if(isset($_POST['btn_search'])){
	header('location: search.php');
}
if(isset($_POST['btn_explore'])){
	header('location: explore.php');
}


//---------------- manager modify food-----------------//
if(isset($_POST['btn_modify_food'])){
	header('location: modifyfooditem.php');
}
if(isset($_POST['btn_modify_table'])){
	header('location: modifytableitem.php');
}
if(isset($_POST['btn_modify_order'])){
	header('location: managerModifyOrder.php');
}
if(isset($_POST['stf_modify_order'])){
	header('location: managerModifyOrder.php');
}


if (isset($_GET['logout'])) {
 unset($_SESSION['username']);
 unset($_SESSION['customer_logged']);
 unset($_SESSION['manager_logged']);
 unset($_SESSION['staff_logged']);
 unset($_SESSION['modify_info']);
 header("location: homepage.php");
}

if (isset($_GET['modify_personal_info'])) {
	$_SESSION['modify_info'] = "yes";
 header('location: modifypersonalinfo.php');
}

	unset($_SESSION['changeTable']);


 ?>

<!-- ---------------- changed-----------------// -->
<!-- Welcome -->
 <?php  if (isset($_SESSION['username'])) : ?>
	<p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>
	<p> <a href="homepage.php?logout='1'" style="color: red;">logout</a> </p>
	<p> <a href="homepage.php?modify_personal_info='1'" style="color: blue;">personal information</a> </p>
	<?php $order_id = $_SESSION['order_id']?>
	<p>

 <?php endif ?>


<!-- ---------------- manager -----------------// -->
<?php if(isset($_SESSION['manager_logged'])) : ?>
	<!DOCTYPE html>
	<html>
	<head>
		<title>Manager Page</title>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>

		<div class="header">
			<h2>Manager Page</h2>
		</div>

		<form method="post" action="homepage.php">

			<div class="input-group">

	      <br/><button type="submit" class="button" name="btn_modify_food">Modify Food</button>
				<br/><button type="submit" class="button" name="btn_modify_table">Modify Table</button>
				<br/><button type="submit" class="button" name="btn_modify_order">Modify Order</button>

			</div>
		</form>
	</body>
	</html>
<?php endif ?>

<?php if(isset($_SESSION['staff_logged'])) : ?>
	<!DOCTYPE html>
	<html>
	<head>
		<title>Staff Page</title>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>

		<div class="header">
			<h2>Staff Page</h2>
		</div>

		<form method="post" action="homepage.php">

			<div class="input-group">

				<br/><button type="submit" class="button" name="stf_modify_order">Modify Order</button>

			</div>
		</form>
	</body>
	</html>
<?php endif ?>




<?php if(!isset($_SESSION['manager_logged']) && !isset($_SESSION['staff_logged'])) : ?>
<!DOCTYPE html>
<html>
<head>
	<title>Restaurant Reservation System</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

	<div class="header">
		<h2>Secret of Pepper</h2>
	</div>

	<form method="post" action="homepage.php">

		<div class="input-group">

      <br/><button type="submit" class="button" name="btn_explore">Explore</button>
			<br/><button type="submit" class="button" name="btn_search">Search</button>
       <?php  if (!isset($_SESSION['customer_logged'])) : ?>
				 <br/><button type="submit" class="button" name="btn_login">Login</button>
			 <?php endif ?>
		</div>
	</form>

	<form method="post" action="custModifyOrder.php">
			<?php  if (isset($_SESSION['customer_logged'])) : ?>
				<br/><button type="submit" class="button" name="btn_c_modify_order">Modify My Order</button> 
			<?php endif ?>
	</form>

</body>
</html>
<?php endif ?>
