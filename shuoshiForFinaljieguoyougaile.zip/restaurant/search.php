<html>
 <head>
  <title>Search</title>
 </head>
 <body>
 	 <a href =homepage.php>Back to homepage</a>
	<form action = "search.php" method = "POST">
 		<input type = "text" name = "search-food" placeholder="Search Food">
 		<button type = "submit" name = "submit-search"> Search </button>
	</form>

	 <?php
	 	session_start();
	 	$r_db = mysqli_connect("localhost","root", "", "restaurant");
	 	if (isset($_GET['id'])){
 		  	$food_id = $_GET['id'];
 			$order_id = $_SESSION['order_id'];
 			$se_include_query = "SELECT num_of_food FROM include WHERE order_id = '$order_id' AND food_id = '$food_id'" ;
 			$se_include_result = mysqli_query($r_db, $se_include_query);
 		  	$num_se_include_result = mysqli_num_rows($se_include_result);
 	  		if($num_se_include_result == 1){
 	  			$num_of_food_tuple = mysqli_fetch_assoc($se_include_result);
 	  			$num_of_food = $num_of_food_tuple['num_of_food'];
 	  		 	$num_of_food = $num_of_food + 1;
 	  		 	$increase_num_query = "UPDATE include SET num_of_food = '$num_of_food' WHERE order_id = '$order_id' AND food_id = '$food_id'" ;
 	 		 	$increase_num_result = mysqli_query($r_db, $increase_num_query);

 	  		} else {
 	  			$in_include_query = "INSERT INTO include VALUES ('1', '$food_id', '$order_id')";
 	  			$in_include_result = mysqli_query($r_db, $in_include_query);
 			}
 			echo "<div>You have successfully add the food.</div>";
	 	}
	 ?>
	 <div class = "search-result-container">
	 <?php
	    if (isset($_POST['submit-search'])){?>
	 	<h1>Search result </h1>
	 	<?php
		$food_key_word = $_POST['search-food'];
 		$search_query = "SELECT * FROM food WHERE (name LIKE '%$food_key_word%' OR food_id LIKE '%$food_key_word%') AND availability = 'yes'";
 		$search_result = mysqli_query($r_db, $search_query);
 		$search_num_result = mysqli_num_rows($search_result);
 		if ($search_num_result > 0) {
 			while ($tuple = mysqli_fetch_assoc($search_result)){
 				if (isset($_SESSION['customer_logged'])){
 					echo "<div>
 					<h2>Food name:".$tuple['name']."</h2>
 					<p>Type:".$tuple['type']."</p>
 					<p>Food id:".$tuple['food_id']."</p>
 					<p>Food price:".$tuple['price']."</p>
 				    <p>Picture: <img src=\"".$tuple['picture']."\"></img></p>
 					 <a href =\\restaurant\search.php?id=".$tuple['food_id'].">Add</a>
 					</div>";
 				} else {
 					echo "<div>
 					<h2>Food name:".$tuple['name']."</h2>
 					<p>Type:".$tuple['type']."</p>
 					<p>Food id:".$tuple['food_id']."</p>
 					<p>Food price:".$tuple['price']."</p>
 				    <p>Picture: <img src=\"".$tuple['picture']."\"></img></p>
 					 <a href =\\restaurant\homepage.php>Login in and add the food</a>
 					</div>";
 				} 
 			}
 		}
	}
	?>

	 <?php if (isset($_SESSION['customer_logged'])){?>
 		<div><a href ="\restaurant\addTable.php?">Reserve a table(You can reserve a table without ordering food)</a></div>
 	 	<div><a href ="\restaurant\order.php?">Place the order</a></div>
	 <?php }?>
	 </div>


 </body>
</html>
