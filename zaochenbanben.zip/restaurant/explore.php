﻿<html>
 <head>
  <title>Explore</title>
 </head>
 <body>
 <a href =homepage.php>Back to homepage</a>
 <h1> Explore result </h1>
 <div class = "search-result-container">
 	<?php
 	 session_start();
 	 date_default_timezone_set("America/Edmonton");
 	 echo date("Y-m-d h:i:s");
 	 $r_db = mysqli_connect("localhost","root", "", "restaurant");
 	if (isset($_GET['id'])){
 	  $food_id = $_GET['id'];
 	  $order_id = $_SESSION['order_id'];
 	  $se_include_query = "SELECT num_of_food FROM include WHERE order_id = '$order_id' AND food_id = '$food_id'" ;
 	  $se_include_result = mysqli_query($r_db, $se_include_query);
 	  $num_se_include_result = mysqli_num_rows($se_include_result);
 	  if($num_se_include_result == 1){
 	  		 $num_of_food_tuple = mysqli_fetch_assoc($se_include_result);
 	  		 $num_of_food = $num_of_food_tuple['num_of_food'];
 	  		 $num_of_food = $num_of_food + 1;
 	  		 $increase_num_query = "UPDATE include SET num_of_food = '$num_of_food' WHERE order_id = '$order_id' AND food_id = '$food_id'" ;
 	 		 $increase_num_result = mysqli_query($r_db, $increase_num_query);

 	  } else {
 	  		$in_include_query = "INSERT INTO include VALUES ('1', '$food_id', '$order_id')";
 	  		$in_include_result = mysqli_query($r_db, $in_include_query);
 		}
 		echo "<div>You have successfully add the food.</div>";
 	}

 		$query = "SELECT * FROM food WHERE availability = 'yes'";
 		$result = mysqli_query($r_db, $query);
 		$numResult = mysqli_num_rows($result);
 		if ($numResult > 0) {
 			while ($tuple = mysqli_fetch_assoc($result))
 				echo "<div>
 					<h2>Food name:".$tuple['name']."</h2>
 					<p>Type:".$tuple['type']."</p>
 					<p>Food id:".$tuple['food_id']."</p>
 					<p>Food price:".$tuple['price']."</p>
 				    <p>Picture: <img src=\"".$tuple['picture']."\"></img></p>
 					 <a href =\\restaurant\\explore.php?id=".$tuple['food_id'].">Add</a>
 				</div>";
 		}

 	?>
 	 	<div><a href ="\restaurant\addTable.php?">Reserve a table(You can reserve a table without ordering food)</a></div>
 	 	<div><a href ="\restaurant\order.php?">Modify or place the order</a></div>
 </div>
 </body>
</html>
