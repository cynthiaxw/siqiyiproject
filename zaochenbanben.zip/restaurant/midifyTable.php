<?php
  // Sessions and variables initialization

?>



    <html>
     <head>
      <title>Modify Table</title>

     </head>
     <body>

     <h1> Modify Table </h1>

     <br/><a href="homepage.php">Back to home page.</a>
     <br/><a href="modifytableitem.php?add">Add a new table.</a>

     <div class = "search-result-container">
     	<?php
     	  $r_db = mysqli_connect("localhost","root", "", "restaurant");
     		$query = "SELECT * FROM table_information";
     		$result = mysqli_query($r_db, $query);
     		$numResult = mysqli_num_rows($result);
     		if ($numResult > 0) {
     			while ($tuple = mysqli_fetch_assoc($result))
     				echo "<div>
     					<h2>".$tuple['table_id']."</h3>
     					<p>".$tuple['capacity']."</p>
     					<p>".$tuple['availability']."</p>
     					 <a href =modifyfooditem.php?fid=".$tuple['table_id'].">Modify</a>
               <a href =modifyfooditem.php?delete_id=".$tuple['table_id'].">Delete</a>
     				</div>";

     		}
     	?>
     </div>
     </body>
    </html>



<?php if(!isset($_SESSION['modify_f'])) :?>
  <?php if(!isset($_GET['add'])) : ?>

    <?php if(isset($_GET['fid'])) : ?>
      <?php
        $_SESSION['modify_f'] = 'yes';
        $tmpFoodId = $_GET['fid'];
        $_SESSION['fId'] = $tmpFoodId;
        // Fetch food information from database
        $r_db = mysqli_connect("localhost","root", "", "restaurant");
        $query = "SELECT * FROM food WHERE food_id = '$tmpFoodId'";
        $result = mysqli_query($r_db, $query);
        $tuple = mysqli_fetch_assoc($result);

        $_SESSION['fType'] = $tuple['type'];
        $_SESSION['fName'] = $tuple['name'];
        $_SESSION['fPrice'] = $tuple['price'];
        $_SESSION['fAvailability'] = $tuple['availability'];
        $_SESSION['fPicture'] = $tuple['picture'];

        $_SESSION['modify_f'] = 'yes';

      ?>
    <?php endif ?>

    <?php if(isset($_GET['delete_id'])) : ?>
      <?php
        $tmpFoodId = $_GET['delete_id'];
        $r_db = mysqli_connect("localhost","root", "", "restaurant");
        $query = "DELETE FROM food WHERE food_id = '$tmpFoodId'";
        $result = mysqli_query($r_db, $query);
        header('location: modifyfooditem.php');
      ?>
    <?php endif ?>

  <?php endif ?>
  <?php if(isset($_GET['add'])) : ?>
    <?php
      $_SESSION['add_new_food'] = 'yes';
    ?>
  <?php endif ?>

<?php endif ?>

<?php if(isset($_SESSION['modify_f'])) : ?>


  <!DOCTYPE html>
  <html>
  <head>
  	<title>Modify Food Item</title>
  	<link rel="stylesheet" type="text/css" href="style.css">
  </head>
  <body>

  	<div class="header">
  		<h2>Modify Food Item</h2>
  	</div>

  	<form method="post" action="modifyfooditem.php">

  		<div class="input-group">
        <label>Food Id</label>
        <input type="fId" name="fId" value="<?php echo $_SESSION['fId']; ?>">
        <label>Type</label>
        <input type="fType" name="fType" value="<?php echo $_SESSION['fType']; ?>">
        <label>Name</label>
        <input type="fName" name="fName" value="<?php echo $_SESSION['fName']; ?>">
        <label>Price</label>
        <input type="fPrice" name="fPrice" value="<?php echo $_SESSION['fPrice']; ?>">
        <label>Availability</label>
        <input type="fAvailability" name="fAvailability" value="<?php echo $_SESSION['fAvailability']; ?>">
        <label>Picture</label>
        <input type="fPicture" name="fPicture" value="<?php echo $_SESSION['fPicture']; ?>">


        <br/><button type="submit" class="button" name="btn_modifyf_confirm">Confirm</button>
  			<br/><button type="submit" class="button" name="btn_modifyf_cancel">Cancel</button>

        <?php


        ?>

  		</div>
  	</form>
  </body>
  </html>

  <?php
    if(isset($_POST['btn_modifyf_cancel'])){
      unset($_SESSION['modify_f']);
      header('location: modifyfooditem.php');
    }


    if(isset($_POST['btn_modifyf_confirm'])){
      $r_db = mysqli_connect("localhost","root", "", "restaurant");

      $tmpFoodId = mysqli_real_escape_string($r_db, $_POST['fId']);
      $tmpFoodType = mysqli_real_escape_string($r_db, $_POST['fType']);
      $tmpFoodName = mysqli_real_escape_string($r_db, $_POST['fName']);
      $tmpFoodPrice = mysqli_real_escape_string($r_db, $_POST['fPrice']);
      $tmpFoodAvalability = mysqli_real_escape_string($r_db, $_POST['fAvailability']);

      $query = "UPDATE food
                SET type = '$tmpFoodType', name = '$tmpFoodName', price = '$tmpFoodPrice', availability = '$tmpFoodAvalability'
                WHERE food_id = '$tmpFoodId'";
      $result = mysqli_query($r_db, $query);

      unset($_SESSION['modify_f']);
      header('location: modifyfooditem.php');

    }
  ?>

<?php endif ?>
