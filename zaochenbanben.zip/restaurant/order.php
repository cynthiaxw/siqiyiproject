﻿<html>
 <head>
  <title>Order information</title>

 </head>
 <body>
 	 <a href =homepage.php>Back to homepage (and add more food)</a>
 	<?php
 	  session_start();
 	// check if place order button is pressed
    if(isset($_POST['place_order'])){

  		$r_db = mysqli_connect("localhost","root", "", "restaurant");
  		$order_id = $_SESSION['order_id'];
  		$order_state = 'processing';
  		date_default_timezone_set("America/Edmonton");
  		$order_time = date("Y-m-d h:i:s");
  		$place_order_query = "UPDATE customer_order SET Order_state = '$order_state'  WHERE order_id = '$order_id'" ;
  		$place_order_result = mysqli_query($r_db, $place_order_query);
  		$place_order_query = "UPDATE customer_order SET order_Place_Time = '$order_time'  WHERE order_id = '$order_id'" ;
  		$place_order_result = mysqli_query($r_db, $place_order_query);


  		$din_in_or_take_away = $_POST['din-in-or-take-away'];
  		$food_restriction =  $_POST['food-restriction']; 
  		$cost = $_SESSION['cost'];
  		$food_order_query = "INSERT INTO food_order (food_restriction, din_in_or_take_away, cost, order_id)
  							VALUES ('$food_restriction', '$din_in_or_take_away', '$cost', '$order_id')";
  		$food_order_result =  mysqli_query($r_db, $food_order_query);

  		$number_of_person = $_POST['number-of-person'];
  		$update_table_query = "UPDATE table_order SET num_of_person = '$number_of_person'  WHERE order_id = '$order_id'" ;
  		$update_table_result = mysqli_query($r_db, $update_table_query);

    	$username = $_SESSION['username'];
		$order_query = "SELECT order_id FROM customer_order WHERE Order_state = 'not_placed' AND cust_name = '$username'";
		$order_result = mysqli_query($r_db, $order_query);
		$order_tuple =mysqli_fetch_assoc($order_result);
		if (mysqli_num_rows($order_result) >= 1) {
 			$_SESSION['order_id'] = $order_tuple['order_id'];
		} else{
			$max_order_id_query = "SELECT MAX(order_id) as max_order_id FROM  customer_order";
			$max_order_id_results = mysqli_query($r_db, $max_order_id_query);
			$max_order_id_tuple = mysqli_fetch_assoc($max_order_id_results);
			$new_order_id =  $max_order_id_tuple['max_order_id']+1;
			$_SESSION['order_id'] = $new_order_id;
			$insert_order_query = "INSERT INTO customer_order(order_id, Order_state, Cancellability, cust_name)
									VALUES ('$new_order_id', 'not_placed', 'yes', '$username')";
			$insert_order_resutl = mysqli_query($r_db, $insert_order_query);
		}    	
      header('location: homepage.php');

  	}

 	// modify processing order
 	  if (isset($_GET['orderId'])){
 		  $r_db = mysqli_connect("localhost","root", "", "restaurant");
 		  $order_id = $_GET['orderId'];
 		  $_SESSION['order_id'] = $order_id;
 	  }


	// change food quantity or delete food
 	  $r_db = mysqli_connect("localhost","root", "", "restaurant");
 	  $order_id = $_SESSION['order_id'];
 	  if (isset($_GET['id'])){
 	  $food_id = $_GET['id'];
 	  $order_id = $_SESSION['order_id'];
 	  $action = $_GET['action'];
 	  $se_include_query = "SELECT num_of_food FROM include WHERE order_id = '$order_id' AND food_id = '$food_id'" ;
 	  $se_include_result = mysqli_query($r_db, $se_include_query);
 	  $num_se_include_result = mysqli_num_rows($se_include_result);
 	  if($action == 'increase'){
 		  	if($num_se_include_result == 1){
 	  			$num_of_food_tuple = mysqli_fetch_assoc($se_include_result);
 	  			$num_of_food = $num_of_food_tuple['num_of_food'];
 	  		 	$num_of_food = $num_of_food + 1;
 	  		 	$increase_num_query = "UPDATE include SET num_of_food = '$num_of_food' WHERE order_id = '$order_id' AND food_id = '$food_id'" ;
 	 		 	$increase_num_result = mysqli_query($r_db, $increase_num_query);

 	  		} else {
 	  			$in_include_query = "INSERT INTO include VALUES ('1', '$food_id', '$order_id')";
 	  			$in_include_result = mysqli_query($r_db, $in_include_query);
 			}
 			echo "<div>You have successfully increased the quantity of the food.</div>";
 	   } else if ($action == 'reduce'){
 	   	 	$num_of_food_tuple = mysqli_fetch_assoc($se_include_result);
 	  		$num_of_food = $num_of_food_tuple['num_of_food'];
 	   	 	if($num_of_food > 1){
 	  		 	$num_of_food = $num_of_food - 1;
 	  		 	$increase_num_query = "UPDATE include SET num_of_food = '$num_of_food' WHERE order_id = '$order_id' AND food_id = '$food_id'" ;
 	 		 	$increase_num_result = mysqli_query($r_db, $increase_num_query);
 	  		} else {
 	  			$de_include_query = "DELETE FROM include WHERE order_id = '$order_id' AND food_id = '$food_id'";
 	  			$de_include_result = mysqli_query($r_db, $de_include_query);
 			}
 			echo "<div>You have successfully reduced the quantity of the food.</div>";
 	   } else {
 	  			$de_include_query = "DELETE FROM include WHERE order_id = '$order_id' AND food_id = '$food_id'";
 	  			$de_include_result = mysqli_query($r_db, $de_include_query);
 	  		echo "<div>You have successfully deleted the quantity of the food.</div>";
 	   }
 	  }



 	  // print order information
 	  $check_table_order_query = "SELECT * FROM  table_order O INNER JOIN table_time_slot T WHERE O.table_id=T.table_id AND O.table_start_time = T.table_start_time AND O.order_id = '$order_id'";
 	  $check_table_order_result = mysqli_query($r_db, $check_table_order_query);
 	  $num_table_order_result = mysqli_num_rows($check_table_order_result);
 	  if ($num_table_order_result >= 1) {
 	  	while ($table_tuple = mysqli_fetch_assoc($check_table_order_result)){
 	  	 echo "<div><h2>You have made a reservation: </h2></div>";
 	  	 echo "<div><p>Table  ".$table_tuple['table_id']."</p>
 	  	             <p>Table  ".$table_tuple['table_start_time']."</p>
 	  	             <a href =\\restaurant\changeTable.php?>Change reservation</a>
 	  	             </div>";
 	  	 $_SESSION['changeTable'] = 1;
 	  	}
	}
 	?>

 	<div>
 		 <?php
 		$cost = 0;
 	  	$r_db = mysqli_connect("localhost","root", "", "restaurant");
 	  	$order_id = $_SESSION['order_id'];
 		$query = "SELECT * FROM include NATURAL JOIN food WHERE order_id = $order_id";
 		$result = mysqli_query($r_db, $query);
 		$numResult = mysqli_num_rows($result);
 		if ($numResult > 0) {
 			 echo "<p><h2> Your have ordered the food:</h2></p>";
 			while ($tuple = mysqli_fetch_assoc($result)){
 				echo "<div>
 				 	<h2>Food name:".$tuple['name']."</h2>
 					<p>Type:".$tuple['type']."</p>
 					<p>Food id:".$tuple['food_id']."</p>
 					<p>Food price:".$tuple['price']."</p>
 					<p>Quantity:".$tuple['Num_of_food']."</p>
 				    <p>Picture: <img src=\"".$tuple['picture']."\"></img></p>
 				     <a href =\\restaurant\order.php?id=".$tuple['food_id']."&action=reduce>Reduce</a>
 					 <a href =\\restaurant\order.php?id=".$tuple['food_id']."&action=increase>Increase</a>
 					 <a href =\\restaurant\order.php?id=".$tuple['food_id']."&action=delete>Delete</a>
 				</div>";
 				$cost = $tuple['Num_of_food'] * $tuple['price'] + $cost;
 			}
 			echo "<div>Total cost: $cost</div>";
 			$_SESSION['cost'] = $cost;
 		}?>
    <form method="post" action="order.php?">
    	<div><input type = "text" name = "number-of-person" style="width:300px;height:23px;" placeholder="Number of person."></div>
    	<div><input type = "text" name = "din-in-or-take-away" style="width:300px;height:23px;" placeholder="Din in or take away."></div>
 	   	<div><input type = "text" name = "food-restriction" style="width:300px;height:46px;" placeholder="Requirement or ristriction about food."></div>
  	  	<div><button type="submit" class="button" name="place_order">Place the order</button></div>
    </form>
 	</div>


 </body>
</html>
