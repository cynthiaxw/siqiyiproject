<html>
 <head>
  <title>Search</title>
 </head>
 <body>
 	 <a href =homepage.php>Back to homepage</a>
	<form action = "managerModifyOrder.php" method = "POST">
 		<input type = "text" name = "search-order" placeholder="Search Order">
 		<button type = "submit" name = "submit-search"> Search </button>
	</form>

	 <?php
	 	session_start();
	 	$r_db = mysqli_connect("localhost","root", "", "restaurant");
	 	if (isset($_GET['deleteid'])){
 		  $order_id = $_GET['deleteid'];
 			$se_include_query = "DELETE FROM customer_order WHERE order_id = '$order_id'" ;
 			$se_include_result = mysqli_query($r_db, $se_include_query);

 			echo "<div>You have successfully deleted the order.</div>";
	 	}
    if (isset($_GET['finishid'])){
      $order_id = $_GET['finishid'];
      $se_include_query = "UPDATE customer_order
                           SET order_state = 'finished', cancellability = 'no'
                           WHERE order_id = '$order_id'" ;
      $se_include_result = mysqli_query($r_db, $se_include_query);

      echo "<div>You have successfully finished the order.</div>";
    }
	 ?>
	 <div class = "search-result-container">
	 <?php
	    if (isset($_POST['submit-search'])){?>
	 	<h1>Search result </h1>
	 	<?php
		$food_key_word = $_POST['search-order'];
 		$search_query = "SELECT * FROM customer_order WHERE order_id LIKE '%$food_key_word%' OR cust_name LIKE '%$food_key_word%'";
 		$search_result = mysqli_query($r_db, $search_query);
 		$search_num_result = mysqli_num_rows($search_result);
 		if ($search_num_result > 0) {
 			while ($tuple = mysqli_fetch_assoc($search_result)){
 				echo "<div>
 					<h2>Order Id: ".$tuple['order_id']."</h2>
          			<p><h2>Customer name: ".$tuple['cust_name']."</h2></p>
 					<p>Order state: \t".$tuple['Order_state']."</p>
 					<p>Order place time: \t".$tuple['order_Place_Time']."</p>
 					<p>cancellability: \t".$tuple['cancellability']."</p>
 					<a href =\\restaurant\managerModifyOrder.php?deleteid=".$tuple['order_id'].">Delete</a>
        </div>";
        if($tuple['Order_state'] == "processing"){
          echo"<a href =\\restaurant\managerModifyOrder.php?finishid=".$tuple['order_id'].">Finish Order</a>";
        }
      }
 		}
	}
	?>

	 </div>


 </body>
</html>
