﻿<html>
 <head>
  <title>Order information</title>	

 </head>
 <body>
 	 <a href =\try\homepage.php>Back to homepage</a>
 	<?php
 	  session_start();
 	  $r_db = mysqli_connect("localhost","root", "", "resturant");
 	  $order_id = $_SESSION['order_id'];
 	  $check_table_order_query = "SELECT * FROM  table_order O INNER JOIN table_time_slot T WHERE O.table_id=T.table_id AND O.table_start_time = T.table_start_time AND O.order_id = '$order_id'";
 	  $check_table_order_result = mysqli_query($r_db, $check_table_order_query);
 	  $num_table_order_result = mysqli_num_rows($check_table_order_result);
 	  if ($num_table_order_result == 1) {
 	  	while ($table_tuple = mysqli_fetch_assoc($check_table_order_result)){
 	  	 echo "<div><h2>You have made a reservation: </h2></div>";
 	  	 echo "<div><p>Table  ".$table_tuple['table_id']."</p>
 	  	             <p>Table  ".$table_tuple['table_start_time']."</p>
 	  	             <a href =\changeTable.php?>Change reservation</a>
 	  	             </div>";
 	  	 $_SESSION['changeTable'] = 1;
 	  	}
	}
 	?>

 	<div>
 		<p><h2> Your have ordered the food:</h2></p>
 		 <?php
 	  	$r_db = mysqli_connect("localhost","root", "", "resturant");
 	  	$order_id = $_SESSION['order_id'];
 		$query = "SELECT * FROM include NATURAL JOIN food WHERE order_id = $order_id";
 		$result = mysqli_query($r_db, $query);
 		$numResult = mysqli_num_rows($result);
 		if ($numResult > 0) {
 			while ($tuple = mysqli_fetch_assoc($result))
 				echo "<div>
 					<h2>".$tuple['type']."</h3>
 					<p>".$tuple['food_id']."</p>
 					<p>".$tuple['name']."</p>
 					<p>".$tuple['availability']."</p>
 					<p>".$tuple['price']."</p>
 					<p> quantity:".$tuple['Num_of_food']."</p>
 				    <p><img src=\"".$tuple['picture']."\"></img></p>
 					 <a href =\updateExplore.php?id=".$tuple['food_id'].">Add</a>
 				</div>";
 		}

 	?>
 	</div>

 </body>
</html>