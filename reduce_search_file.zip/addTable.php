﻿<html>
 <head>
  <title>Reserve a table</title>	

 </head>
 <body>
 	 <a href =\try\homepage.php>Back to homepage</a>
 	<?php
 	  session_start();
 	  $r_db = mysqli_connect("localhost","root", "", "resturant");
 	  $order_id = $_SESSION['order_id'];
 	  $check_table_order_query = "SELECT * FROM  table_order O INNER JOIN table_time_slot T WHERE O.table_id=T.table_id AND O.table_start_time = T.table_start_time AND O.order_id = '$order_id'";
 	  $check_table_order_result = mysqli_query($r_db, $check_table_order_query);
 	  $num_table_order_result = mysqli_num_rows($check_table_order_result);
 	  if ($num_table_order_result == 1) {
 	  	while ($table_tuple = mysqli_fetch_assoc($check_table_order_result)){
 	  	 echo "<div>You have made a reservation: </div>";
 	  	 echo "<div><p>Table  ".$table_tuple['table_id']."</p>
 	  	             <p>Table  ".$table_tuple['table_start_time']."</p>
 	  	             <a href =\changeTable.php?>Change reservation</a>
 	  	             </div>";
 	  	 $_SESSION['changeTable'] = 1;
 	  	}
 	  } else {
 	  $se_table_query = "SELECT * FROM table_information WHERE availability = 'YES'" ;
 	  $se_table_result = mysqli_query($r_db, $se_table_query);
 	  $num_result = mysqli_num_rows($se_table_result);
 		if ($num_result > 0) {
 			while ($table_tuple = mysqli_fetch_assoc($se_table_result))
 				echo "<div>
 					<h2>".$table_tuple['table_id']."</h2>
 					<p>".$table_tuple['capacity']."</p>
 					 <a href =\\tableTimeSlot.php?table_id=".$table_tuple['table_id'].">Add</a>
 				</div>";

 		}
 	}
 	?>



 </div>
 </body>
</html>