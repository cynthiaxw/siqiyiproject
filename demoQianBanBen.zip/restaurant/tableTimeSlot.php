﻿<html>
 <head>
  <title>Reserve a table</title>

 </head>
 <body>
 	 <a href =homepage.php>Back to homepage</a>
 	<?php
 	  session_start();
 	  $r_db = mysqli_connect("localhost","root", "", "restaurant");
 	  $table_id = $_GET['table_id'];
 	  $se_time_query = "SELECT * FROM table_time_slot WHERE table_id = '$table_id'" ;
 	  $se_time_result = mysqli_query($r_db, $se_time_query);
 	  $num_result = mysqli_num_rows($se_time_result);
 		if ($num_result > 0) {
 			while ($time_tuple = mysqli_fetch_assoc($se_time_result)){
 				if (isset($_SESSION['changeTable'])){
 				echo "<div>
 					<h2>".$time_tuple['table_id']."</h2>
 					<p>".$time_tuple['table_start_time']."</p>
 					 <a href =\\restaurant\addToTableOrder.php?table_id=".$time_tuple['table_id']."&start_time=".$time_tuple['table_start_time'].">Change to this time</a>
 				</div>";
 				} else {
 				 echo "<div>
 					<h2>".$time_tuple['table_id']."</h2>
 					<p>".$time_tuple['table_start_time']."</p>
 					 <a href =\\restaurant\addToTableOrder.php?table_id=".$time_tuple['table_id']."&start_time=".$time_tuple['table_start_time'].">Add to order</a>
 				</div>";
 				}
 			}
 		}

 	?>



 </div>
 </body>
</html>
