<?php
  session_start();
?>


<?php if(!isset($_SESSION['add_table'])) :?>

  <?php if(!isset($_SESSION['modify_table'])) : ?>

    <?php if(!isset($_GET['add'])) :?>

      <?php if(!isset($_GET['tid'])) : ?>
        <html>
         <head>
          <title>Modify Table</title>

         </head>
         <body>

         <h1> Modify Table </h1>

         <br/><a href="homepage.php">Back to home page.</a>
         <br/><a href="modifytableitem.php?add">Add a new table.</a>

         <div class = "search-result-container">
         	<?php
         	  $r_db = mysqli_connect("localhost","root", "", "restaurant");
         		$query = "SELECT * FROM table_information";
         		$result = mysqli_query($r_db, $query);
         		$numResult = mysqli_num_rows($result);
         		if ($numResult > 0) {
         			while ($tuple = mysqli_fetch_assoc($result))
         				echo "<div>
         					<h2>".$tuple['table_id']."</h3>
         					<p>".$tuple['capacity']."</p>
         					<p>".$tuple['availability']."</p>
         					 <a href =modifytableitem.php?tid=".$tuple['table_id'].">Modify</a>
                   <a href =modifytableitem.php?delete_id=".$tuple['table_id'].">Delete</a>
                   <a href =modifyTableTimeSlot.php?time_slot_tid=".$tuple['table_id'].">Time Slot</a>
         				</div>";
         		}
         	?>
         </div>
         </body>
        </html>
      <?php endif ?>

      <?php if(isset($_GET['tid'])) : ?>
        <?php
          // Fetch table information from database
          $tmpTableId = $_GET['tid'];
          $_SESSION['tId'] = $tmpTableId;
          $r_db = mysqli_connect("localhost","root", "", "restaurant");
          $query = "SELECT * FROM table_information WHERE table_id = '$tmpTableId'";
          $result = mysqli_query($r_db, $query);
          $tuple = mysqli_fetch_assoc($result);

          $_SESSION['tCapacity'] = $tuple['capacity'];
          $_SESSION['tAvailability'] = $tuple['availability'];

          $_SESSION['modify_table'] = 'yes';
        ?>
      <?php endif?>

      <?php if(isset($_GET['delete_id'])) : ?>
        <?php
          $tmpTableId = $_GET['delete_id'];
          $r_db = mysqli_connect("localhost","root", "", "restaurant");
          $query = "DELETE FROM table_information WHERE table_id = '$tmpTableId'";
          $result = mysqli_query($r_db, $query);
          header('location: modifytableitem.php');
        ?>
      <?php endif?>

    <?php endif ?>

    <?php if(isset($_GET['add'])) : ?>
      <?php
        $_SESSION['add_table'] = 'yes';
      ?>
    <?php endif?>

  <?php endif ?>

  <?php if(isset($_SESSION['modify_table'])) : ?>
      <!DOCTYPE html>
      <html>
      <head>
        <title>Modify Table Information</title>
        <link rel="stylesheet" type="text/css" href="style.css">
      </head>
      <body>

        <div class="header">
          <h2>Modify Table Information</h2>
        </div>

        <form method="post" action="modifytableitem.php?">

          <div class="input-group">
            <label>Table Id</label>
            <input type="tId" name="tId" value="<?php echo $_SESSION['tId']; ?>">
            <label>Capacity</label>
            <input type="tCapacity" name="tCapacity" value="<?php echo $_SESSION['tCapacity']; ?>">
            <label>Availability</label>
            <input type="tAvailability" name="tAvailability" value="<?php echo $_SESSION['tAvailability']; ?>">
            <br/><button type="submit" class="button" name="btn_modifyt_confirm">Confirm</button>
            <br/><button type="submit" class="button" name="btn_modifyt_cancel">Cancel</button>

          </div>
        </form>
      </body>
      </html>

      <?php
        if(isset($_POST['btn_modifyt_cancel'])){
            unset($_SESSION['modify_table']);
            header('location: modifytableitem.php');
        }

        if(isset($_POST['btn_modifyt_confirm'])){
            $lastTableId = $_SESSION['tId'];
            $r_db = mysqli_connect("localhost","root", "", "restaurant");

            $tmpTableId = mysqli_real_escape_string($r_db, $_POST['tId']);
            $tmpTableCapacity = mysqli_real_escape_string($r_db, $_POST['tCapacity']);
            $tmpTableAvalability = mysqli_real_escape_string($r_db, $_POST['tAvailability']);
            $query = "UPDATE table_information
                      SET table_id = '$tmpTableId', availability = '$tmpTableAvalability', capacity = '$tmpTableCapacity'
                      WHERE table_id = '$lastTableId'";
            $result = mysqli_query($r_db, $query);

            unset($_SESSION['modify_table']);
            header('location: modifytableitem.php');
          }

        ?>

  <?php endif ?>

<?php endif ?>


<?php if(isset($_SESSION['add_table'])) : ?>

  <?php
    $_SESSION['tId'] = "";
    $_SESSION['tCapacity'] = "";
    $_SESSION['tAvailability'] = "";
   ?>
    <!DOCTYPE html>
    <html>
    <head>
      <title>Add New Table Item</title>
      <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>

      <div class="header">
        <h2>Add New Table Item</h2>
      </div>

      <form method="post" action="modifytableitem.php?add">

        <div class="input-group">
          <label>Table Id</label>
          <input type="tId" name="tId" value="<?php echo $_SESSION['tId']; ?>">
          <label>Capacity</label>
          <input type="tCapacity" name="tCapacity" value="<?php echo $_SESSION['tCapacity']; ?>">
          <label>Availability</label>
          <input type="tAvailability" name="tAvailability" value="<?php echo $_SESSION['tAvailability']; ?>">
          <br/><button type="submit" class="button" name="btn_addt_confirm">Confirm</button>
          <br/><button type="submit" class="button" name="btn_addt_cancel">Cancel</button>

        </div>
      </form>
    </body>
    </html>

    <?php if(isset($_POST['btn_addt_cancel'])) : ?>
      <?php
        unset($_SESSION['add_table']);
        header('location: modifytableitem.php');
      ?>
    <?php endif ?>

    <?php if(isset($_POST['btn_addt_confirm'])) : ?>
      <?php
        $r_db = mysqli_connect("localhost","root", "", "restaurant");

        $tmpTableId = mysqli_real_escape_string($r_db, $_POST['tId']);
        $tmpTableCapacity = mysqli_real_escape_string($r_db, $_POST['tCapacity']);
        $tmpTableAvalability = mysqli_real_escape_string($r_db, $_POST['tAvailability']);

        $query = "INSERT INTO table_information(table_id, availability, capacity)
                  VALUES ('$tmpTableId', '$tmpTableAvalability', '$tmpTableCapacity')";
        $result = mysqli_query($r_db, $query);

        $query = "INSERT INTO table_time_slot(table_id, table_start_time, table_end_time)
                  VALUES ('$tmpTableId', '7:30', '9:00'),
                         ('$tmpTableId', '9:00', '10:30'),
                         ('$tmpTableId', '10:30', '12:00'),
                         ('$tmpTableId', '12:00', '13:30'),
                         ('$tmpTableId', '13:30', '15:00'),
                         ('$tmpTableId', '15:00', '16:30'),
                         ('$tmpTableId', '16:30', '18:00'),
                         ('$tmpTableId', '18:00', '19:30'),
                         ('$tmpTableId', '19:30', '21:00'),
                         ('$tmpTableId', '21:00', '22:30')
                  ";
        $result = mysqli_query($r_db, $query);          
        unset($_SESSION['add_table']);
        header('location: modifytableitem.php');
      ?>
    <?php endif ?>
<?php endif ?>
