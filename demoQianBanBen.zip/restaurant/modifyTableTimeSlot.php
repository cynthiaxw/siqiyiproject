<?php
  session_start();
  if(isset($_GET['time_slot_tid'])){
    $_SESSION['tid'] = $_GET['time_slot_tid'];
    unset($_SESSION['add_timeslot']);
  }
?>

<?php if(isset($_SESSION['tid'])) : ?>
  <?php
    if(isset($_GET['add'])){
      $_SESSION['add_timeslot'] = 'yes';
      $_SESSION['tStartTime'] = "";
      $_SESSION['tEndTime'] = "";
    }
  ?>

  <?php
    if(isset($_POST['btn_addt_cancel'])){
      unset($_SESSION['add_timeslot']);
    }
  ?>


  <?php if(isset($_SESSION['add_timeslot'])) : ?>


    <!DOCTYPE html>
    <html>
    <head>
      <title>Add New Time Slot</title>
      <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>

      <div class="header">
        <h2>Add New Time Slot</h2>
      </div>

      <form method="post" action="modifyTableTimeSlot.php?add">

        <div class="input-group">
          <label>Start Time</label>
          <input type="tStartTime" name="tStartTime" value="<?php echo $_SESSION['tStartTime']; ?>">
          <label>End Time</label>
          <input type="tEndTime" name="tEndTime" value="<?php echo $_SESSION['tEndTime']; ?>">

          <br/><button type="submit" class="button" name="btn_addt_confirm">Confirm</button>
          <br/><button type="submit" class="button" name="btn_addt_cancel">Cancel</button>

        </div>
      </form>
    </body>
    </html>


      <?php
        if(isset($_POST['btn_addt_confirm'])){
          printf("!!!!%s", $_SESSION['tid']);

          $r_db = mysqli_connect("localhost","root", "", "restaurant");

          $tmpTableId =  $_SESSION['tid'];
          $tmpStartTime =  mysqli_real_escape_string($r_db, $_POST['tStartTime']);
          $tmpEndTime = mysqli_real_escape_string($r_db, $_POST['tEndTime']);

          $query = "INSERT INTO table_time_slot(table_id, table_start_time, table_end_time)
                    VALUES ('$tmpTableId', '$tmpStartTime', '$tmpEndTime')";
          $result = mysqli_query($r_db, $query);


          unset($_SESSION['add_timeslot']);
          header('location: modifyTableTimeSlot.php');
        }
      ?>

  <?php endif ?>

  <?php if(!isset($_SESSION['add_timeslot'])) : ?>
    <html>
     <head>
      <title>Table Time Slot</title>

     </head>
     <body>

     <h1>Table Time Slot</h1>

     <br/><a href="homepage.php">Back to home page.</a>
     <br/><a href="modifyTableTimeSlot.php?add">Add a new slot.</a>

     <div class = "search-result-container">
      <?php
        echo" <br/><h2>Table ID: ".$_SESSION['tid']."</h3>";

        $tableId = $_SESSION['tid'];
        $r_db = mysqli_connect("localhost","root", "", "restaurant");
        $query = "SELECT * FROM table_time_slot
                  WHERE table_id = '$tableId'";
        $result = mysqli_query($r_db, $query);
        $numResult = mysqli_num_rows($result);
        if ($numResult > 0) {
          while ($tuple = mysqli_fetch_assoc($result))
            echo "<div>
              <p>Start time: ".$tuple['table_start_time']."</p>
              <p>End time: ".$tuple['table_end_time']."</p>

               <a href =modifyTableTimeSlot.php?start_time=".$tuple['table_start_time'].">Delete</a>
            </div>";
        }
      ?>
     </div>
     </body>
    </html>
  <?php endif ?>


<?php endif ?>
<!--

    <?php
      if(isset($_GET['start_time'])){
        $tmp_start_time = $_GET['start_time'];
        $tableId = $_SESSION['tid'];
        $r_db = mysqli_connect("localhost","root", "", "restaurant");
        $query = "DELETE FROM table_time_slot
                  WHERE table_id = '$tableId'
                        AND table_start_time = '$tmp_start_time'";
        $result = mysqli_query($r_db, $query);
        header('location: modifyTableTimeSlot.php');
      }
    ?> -->
