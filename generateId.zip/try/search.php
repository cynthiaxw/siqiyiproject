<html>
 <head>
  <title>Explore</title>	

 </head>
 <body>
	<form action = "search.php" method = "POST">
 		<input type = "text" name = "search food" placeholder="Search Food">
 		<button type = "submit" name = "submit-search"> Search </button>
	</form>

	<?php
	session_start();

	if (isset($_POST['submit-search'])){
		
	}
	?>
 </body>
</html>