﻿<html>
 <head>
  <title>Explore</title>	

 </head>
 <body>

 <h1> Explore result </h1>
 <div class = "search-result-container">
 	<?php
    date_default_timezone_set("America/Edmonton");
 	  echo date("h:i:sa");
 	  session_start();
 	  $r_db = mysqli_connect("localhost","root", "", "resturant");
 		$query = "SELECT * FROM food";
 		$result = mysqli_query($r_db, $query);
 		$numResult = mysqli_num_rows($result);
 		if ($numResult > 0) {
 			while ($tuple = mysqli_fetch_assoc($result))
 				echo "<div>
 					<h2>".$tuple['type']."</h3>
 					<p>".$tuple['food_id']."</p>
 					<p>".$tuple['picture']."</p>
 					<p>".$tuple['name']."</p>
 					<p>".$tuple['availability']."</p>
 					<p>".$tuple['price']."</p>

 					 <a href =\updateExplore.php?id=".$tuple['food_id'].">Add</a>
 				</div>";

 		}
 		 	//	<form method="post" action="order.php">
 			//	<div class = "add_button">
 			//	<button type="add" class="button" name="add_food_to_order">Add</button>
 			//	</div>
 			//	</form>
 					//<button type='add' class='button' name='add_food_to_order'>Add</button>
 	?>
 </div>
 </body>
</html>